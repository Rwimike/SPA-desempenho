// Simulación de base de datos (json-server)
const API_URL = 'http://localhost:3000'; 

// Utilidades de LocalStorage para sesión
function saveSession(user) {
	localStorage.setItem('session', JSON.stringify(user));
}

function getSession() {
	return JSON.parse(localStorage.getItem('session'));
}

function clearSession() {
	localStorage.removeItem('session');
}

// Mostrar notificación
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas fa-${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    toastContainer.appendChild(toast);
    
    // Mostrar toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Ocultar y eliminar después de 4 segundos
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 4000);
}

// Renderizado SPA 
function render(view) {
	const app = document.getElementById('app');
	app.innerHTML = '';
	app.appendChild(view);
}

// Formulario de registro
function registerForm() {
    const div = document.createElement('div');
    div.className = 'auth-container fade-in';
    div.innerHTML = `
        <div class="auth-card card">
            <div class="auth-header">
                <h2><i class="fas fa-user-plus"></i> Crear cuenta</h2>
                <p>Completa el formulario para registrarte</p>
            </div>
            <form id="register">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Nombre de usuario</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Ingresa tu usuario" required>
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Crea una contraseña" required>
                </div>
                <div class="form-group">
                    <label for="role"><i class="fas fa-user-tag"></i> Rol</label>
                    <select class="form-control" id="role" name="role">
                        <option value="visitante">Visitante</option>
                        <option value="admin">Administrador</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-user-plus"></i> Registrarse
                </button>
            </form>
            <div class="form-footer">
                <p>¿Ya tienes una cuenta? <a href="#" id="toLogin">Inicia sesión</a></p>
            </div>
        </div>
    `;
    
    div.querySelector('#register').onsubmit = async (e) => {
        e.preventDefault();
        const button = e.target.querySelector('button[type="submit"]');
        const originalHTML = button.innerHTML;
        button.innerHTML = '<div class="loading"></div> Registrando...';
        button.disabled = true;
        
        const data = Object.fromEntries(new FormData(e.target));
        
        try {
            // Registro en json-server
            await fetch(`${API_URL}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            
            showToast('¡Registro exitoso! Ahora puedes iniciar sesión', 'success');
            
            // Pequeño retraso para que el usuario vea el mensaje
            setTimeout(() => {
                render(loginForm());
            }, 1500);
        } catch (error) {
            showToast('Error en el registro. Inténtalo de nuevo', 'error');
            button.innerHTML = originalHTML;
            button.disabled = false;
        }
    };
    
    div.querySelector('#toLogin').onclick = (e) => {
        e.preventDefault();
        render(loginForm());
    };
    
    return div;
}

// Formulario de login
function loginForm() {
    const div = document.createElement('div');
    div.className = 'auth-container fade-in';
    div.innerHTML = `
        <div class="auth-card card">
            <div class="auth-header">
                <h2><i class="fas fa-sign-in-alt"></i> Iniciar sesión</h2>
                <p>Ingresa tus credenciales para continuar</p>
            </div>
            <form id="login">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Usuario</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Tu nombre de usuario" required>
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Tu contraseña" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-sign-in-alt"></i> Ingresar
                </button>
            </form>
            <div class="form-footer">
                <p>¿No tienes cuenta? <a href="#" id="toRegister">Regístrate aquí</a></p>
            </div>
        </div>
    `;
    
    div.querySelector('#login').onsubmit = async (e) => {
        e.preventDefault();
        const button = e.target.querySelector('button[type="submit"]');
        const originalHTML = button.innerHTML;
        button.innerHTML = '<div class="loading"></div> Iniciando sesión...';
        button.disabled = true;
        
        const data = Object.fromEntries(new FormData(e.target));
        
        try {
            // Autenticación en json-server
            const res = await fetch(`${API_URL}/users?username=${data.username}&password=${data.password}`);
            const users = await res.json();
            
            if (users.length) {
                saveSession(users[0]);
                showToast(`¡Bienvenido ${users[0].username}!`, 'success');
                setTimeout(routeGuard, 1000);
            } else {
                showToast('Usuario o contraseña incorrectos', 'error');
                button.innerHTML = originalHTML;
                button.disabled = false;
            }
        } catch (error) {
            showToast('Error al iniciar sesión', 'error');
            button.innerHTML = originalHTML;
            button.disabled = false;
        }
    };
    
    div.querySelector('#toRegister').onclick = (e) => {
        e.preventDefault();
        render(registerForm());
    };
    
    return div;
}

// Home/dashboard
function dashboard() {
    const user = getSession();
    const div = document.createElement('div');
    div.className = 'fade-in';
    div.innerHTML = `
        <header class="header">
            <div class="container header-content">
                <div class="logo">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Event Manager</span>
                </div>
                <div class="user-info">
                    <span>${user.username} (${user.role})</span>
                </div>
            </div>
        </header>
        
        <div class="dashboard-container">
            <aside class="sidebar">
                <div class="user-info">
                    <h2>${user.username}</h2>
                    <span class="role">${user.role}</span>
                </div>
                
                <nav>
                    <a href="#" class="nav-item active">
                        <i class="fas fa-calendar-check"></i>
                        <span>Eventos</span>
                    </a>
                    <a href="#" class="nav-item">
                        <i class="fas fa-users"></i>
                        <span>Participantes</span>
                    </a>
                    <a href="#" class="nav-item">
                        <i class="fas fa-chart-bar"></i>
                        <span>Reportes</span>
                    </a>
                    <a href="#" class="nav-item">
                        <i class="fas fa-cog"></i>
                        <span>Configuración</span>
                    </a>
					<div class="theme-switcher">
						<button id="themeToggle" class="btn btn-sm btn-outline-secondary">
							<i class="bi bi-moon-fill"></i> Modo Oscuro
						</button>
					</div>
                    <a href="#" id="logout" class="nav-item">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Cerrar sesión</span>
                    </a>
                </nav>
            </aside>
            
            <main class="main-content">
                <div class="section-title">
                    <i class="fas fa-calendar-alt"></i>
                    <h1>Gestión de Eventos</h1>
                </div>


                <div id="content"></div>
            </main>
        </div>
    `;
	setInitialTheme();
	div.querySelector('#themeToggle').addEventListener('click', toggleTheme);
    
    div.querySelector('#logout').onclick = () => {
        clearSession();
        showToast('Sesión cerrada correctamente', 'success');
        setTimeout(routeGuard, 1000);
    };
    
    // Rutas según rol
    const contentContainer = div.querySelector('#content');
    if (user.role === 'admin') {
        adminView(contentContainer);
    } else {
        visitanteView(contentContainer);
    }
    
    return div;
}

// Vista admin: CRUD eventos
function adminView(container) {
    container.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3><i class="fas fa-list"></i> Todos los eventos</h3>
            <button id="createEvent" class="btn btn-primary">
                <i class="fas fa-plus"></i> Crear evento
            </button>
        </div>
        <div class="events-grid" id="eventList"></div>
    `;
    
    loadEvents(container.querySelector('#eventList'));
    
    container.querySelector('#createEvent').onclick = () => {
        render(eventForm());
    };
}

function loadEvents(list) {
    fetch(`${API_URL}/events`)
        .then(r => r.json())
        .then(events => {
            list.innerHTML = '';
            
            if (events.length === 0) {
                list.innerHTML = `
                    <div class="card event-card">
                        <div class="text-center py-5">
                            <i class="fas fa-calendar-times fa-3x mb-3" style="color: #6c757d;"></i>
                            <h4>No hay eventos disponibles</h4>
                            <p class="text-muted">Crea tu primer evento para comenzar</p>
                        </div>
                    </div>
                `;
                return;
            }
            
            events.forEach(event => {
                const eventCard = document.createElement('div');
                eventCard.className = 'card event-card';
                eventCard.innerHTML = `
                    <div class="event-title">${event.nombre}</div>
                    <div class="event-description">${event.descripcion || 'Sin descripción'}</div>
                    
                    <div class="event-meta">
                        <div class="capacity">
                            <i class="fas fa-users"></i> ${event.registrados ? event.registrados.length : 0}/${event.capacidad} cupos
                        </div>
                    </div>
                    
                    <div class="event-actions mt-3">
                        <button data-id="${event.id}" class="btn btn-outline edit w-100">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button data-id="${event.id}" class="btn btn-danger delete w-100">
                            <i class="fas fa-trash-alt"></i> Eliminar
                        </button>
                    </div>
                `;
                
                list.appendChild(eventCard);
            });
            
            list.querySelectorAll('.edit').forEach(btn => {
                btn.onclick = () => render(eventForm(btn.dataset.id));
            });
            
            list.querySelectorAll('.delete').forEach(btn => {
                btn.onclick = async () => {
                    if (confirm('¿Estás seguro de eliminar este evento?')) {
                        await fetch(`${API_URL}/events/${btn.dataset.id}`, { method: 'DELETE' });
                        showToast('Evento eliminado correctamente', 'success');
                        loadEvents(list);
                    }
                };
            });
        });
}

// Formulario crear/editar evento
function eventForm(id = null) {
	const div = document.createElement('div');
	div.className = 'fade-in';
	div.innerHTML = `
			<header class="header">
					<div class="container header-content">
							<div class="logo">
									<i class="fas fa-calendar-alt"></i>
									<span>Event Manager</span>
							</div>
							<div class="user-info">
									<span>${getSession().username}</span>
							</div>
					</div>
			</header>
			
			<div class="container py-5">
					<div class="d-flex align-items-center mb-4">
							<button id="back" class="btn btn-outline me-3">
									<i class="fas fa-arrow-left"></i>
							</button>
							<h2><i class="fas fa-calendar-plus me-2"></i>${id ? 'Editar Evento' : 'Nuevo Evento'}</h2>
					</div>
					
					<div class="event-form card">
							<form id="eventForm">
									<div class="form-group">
											<label for="nombre"><i class="fas fa-heading"></i> Nombre del evento</label>
											<input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del evento" required>
									</div>
									
									<div class="form-group">
											<label for="descripcion"><i class="fas fa-align-left"></i> Descripción</label>
											<textarea class="form-control" id="descripcion" name="descripcion" placeholder="Describe el evento..." rows="3"></textarea>
									</div>
									
									<div class="form-group">
											<label for="capacidad"><i class="fas fa-users"></i> Capacidad</label>
											<input type="number" class="form-control" id="capacidad" name="capacidad" placeholder="Número de participantes" min="1" required>
									</div>
									
									<div class="d-flex justify-content-end gap-2 mt-4">
											<button type="button" id="cancel" class="btn btn-outline">
													<i class="fas fa-times"></i> Cancelar
											</button>
											<button type="submit" class="btn btn-primary">
													<i class="fas fa-save"></i> ${id ? 'Actualizar' : 'Crear Evento'}
											</button>
									</div>
							</form>
					</div>
			</div>
	`;
    
    if (id) {
        fetch(`${API_URL}/events/${id}`)
            .then(r => r.json())
            .then(ev => {
                div.querySelector('[name=nombre]').value = ev.nombre;
                div.querySelector('[name=descripcion]').value = ev.descripcion || '';
                div.querySelector('[name=capacidad]').value = ev.capacidad;
            });
    }
    
    div.querySelector('#eventForm').onsubmit = async (e) => {
        e.preventDefault();
        const button = e.target.querySelector('button[type="submit"]');
        const originalHTML = button.innerHTML;
        button.innerHTML = '<div class="loading"></div> Guardando...';
        button.disabled = true;
        
        const data = Object.fromEntries(new FormData(e.target));
        
		try {
			if (id) {
					await fetch(`${API_URL}/events/${id}`, {
							method: 'PUT',
							headers: { 'Content-Type': 'application/json' },
							body: JSON.stringify(data)
					});
					showToast('Evento actualizado correctamente', 'success');
			} else {
					await fetch(`${API_URL}/events`, {
							method: 'POST',
							headers: { 'Content-Type': 'application/json' },
							body: JSON.stringify({ ...data, registrados: [] })
					});
					showToast('Evento creado correctamente', 'success');
			}
				
			setTimeout(() => render(dashboard()), 1000);
		} catch (error) {
			showToast('Error al guardar el evento', 'error');
			button.innerHTML = originalHTML;
			button.disabled = false;
		}
	};
	
	div.querySelector('#back').onclick = () => render(dashboard());
	div.querySelector('#cancel').onclick = () => render(dashboard());
	
	return div;
}

// Vista visitante: ver y registrarse en eventos
function visitanteView(container) {
	container.innerHTML = `
		<h3><i class="fas fa-calendar-day"></i> Eventos disponibles</h3>
		<div class="events-grid" id="eventList"></div>
	`;
    
	fetch(`${API_URL}/events`)
		.then(r => r.json())
		.then(events => {
			const list = container.querySelector('#eventList');
			list.innerHTML = '';
			
			if (events.length === 0) {
				list.innerHTML = `
					<div class="card event-card">
						<div class="text-center py-5">
							<i class="fas fa-calendar-times fa-3x mb-3" style="color: #6c757d;"></i>
							<h4>No hay eventos disponibles</h4>
							<p class="text-muted">Vuelve más tarde para ver nuevos eventos</p>
						</div>
					</div>
				`;
				return;
			}
					
					events.forEach(ev => {
							const user = getSession();
							const registrados = ev.registrados || [];
							const registrado = registrados.includes(user.username);
							const availableSpots = ev.capacidad - registrados.length;
							
							const eventCard = document.createElement('div');
							eventCard.className = 'card event-card';
							eventCard.innerHTML = `
									<div class="event-title">${ev.nombre}</div>
									<div class="event-description">${ev.descripcion || 'Sin descripción'}</div>
									
									<div class="event-meta">
											<div class="${availableSpots > 0 ? 'capacity' : 'registered'}">
													<i class="fas fa-users"></i> 
													${availableSpots > 0 ? 
															`${availableSpots} cupos disponibles` : 
															'Evento completo'}
											</div>
									</div>
									
									<div class="event-actions mt-3">
											${registrado ? 
													`<button data-id="${ev.id}" class="btn btn-danger unreg w-100">
															<i class="fas fa-user-times"></i> Cancelar registro
													</button>` : 
													`<button data-id="${ev.id}" class="btn btn-primary reg w-100" ${availableSpots === 0 ? 'disabled' : ''}>
															<i class="fas fa-user-plus"></i> Registrarse
													</button>`
											}
									</div>
							`;
							
							list.appendChild(eventCard);
					});
					
					// Botón para registrarse
					list.querySelectorAll('.reg').forEach(btn => {
							btn.onclick = async () => {
									btn.innerHTML = '<div class="loading"></div> Registrando...';
									btn.disabled = true;
									
									const user = getSession();
									const res = await fetch(`${API_URL}/events/${btn.dataset.id}`);
									const evento = await res.json();
									
									if ((evento.registrados || []).length < evento.capacidad) {
											await fetch(`${API_URL}/events/${btn.dataset.id}`, {
													method: 'PATCH',
													headers: { 'Content-Type': 'application/json' },
													body: JSON.stringify({ 
															registrados: [...(evento.registrados || []), user.username] 
													})
											});
											
											showToast('¡Registrado en el evento con éxito!', 'success');
											setTimeout(() => visitanteView(container), 1000);
									} else {
											showToast('Este evento ya está completo', 'warning');
											btn.innerHTML = '<i class="fas fa-user-plus"></i> Registrarse';
											btn.disabled = true;
									}
							};
					});
					
					// Botón para eliminar registro
					list.querySelectorAll('.unreg').forEach(btn => {
							btn.onclick = async () => {
									btn.innerHTML = '<div class="loading"></div> Cancelando...';
									btn.disabled = true;
									
									const user = getSession();
									const res = await fetch(`${API_URL}/events/${btn.dataset.id}`);
									const evento = await res.json();
									const nuevosRegistrados = (evento.registrados || []).filter(u => u !== user.username);
									
									await fetch(`${API_URL}/events/${btn.dataset.id}`, {
											method: 'PATCH',
											headers: { 'Content-Type': 'application/json' },
											body: JSON.stringify({ registrados: nuevosRegistrados })
									});
									
									showToast('Registro cancelado correctamente', 'success');
									setTimeout(() => visitanteView(container), 1000);
							};
					});
			});
}

// Ruta protegida y lógica de navegación
function routeGuard() {
    const user = getSession();
    if (!user) {
        render(loginForm());
    } else {
        render(dashboard());
    }
}

// Funciones para manejar el tema oscuro/claro
function setInitialTheme() {
  const savedTheme = localStorage.getItem('theme') || 'light';
  applyTheme(savedTheme);
}

function applyTheme(theme) {
  document.body.setAttribute('data-bs-theme', theme);
  localStorage.setItem('theme', theme);
  
  // Actualiza el icono y texto del botón
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    if (theme === 'dark') {
      themeToggle.innerHTML = '<i class="bi bi-sun-fill"></i> Modo Claro';
      themeToggle.classList.remove('btn-outline-secondary');
      themeToggle.classList.add('btn-outline-warning');
    } else {
			themeToggle.innerHTML = '<i class="bi bi-moon-fill"></i> Modo Oscuro';
			themeToggle.classList.remove('btn-outline-warning');
			themeToggle.classList.add('btn-outline-secondary');
    }
  }
}
document.querySelectorAll('.theme-option').forEach(option => {
  option.addEventListener('click', function(e) {
    e.preventDefault();
    const theme = this.getAttribute('data-theme');
    applyTheme(theme);
  });
});

function applyTheme(theme) {
  let selectedTheme = theme;
  
  if (theme === 'auto') {
    selectedTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  
  document.body.setAttribute('data-bs-theme', selectedTheme);
  localStorage.setItem('theme', theme); 
  
  
  const dropdownButton = document.getElementById('themeDropdown');
  if (dropdownButton) {
    const activeOption = document.querySelector(`.theme-option[data-theme="${theme}"]`);
    if (activeOption) {
      dropdownButton.innerHTML = activeOption.innerHTML;
    }
  }
}
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
  if (localStorage.getItem('theme') === 'auto') {
    applyTheme('auto');
  }
});
function toggleTheme() {
  const currentTheme = document.body.getAttribute('data-bs-theme') || 'light';
  const newTheme = currentTheme === 'light' ? 'dark' : 'light';
  applyTheme(newTheme);
}

// Persistencia de sesión al recargar
window.onload = routeGuard;
